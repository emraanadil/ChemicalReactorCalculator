prompt = ["Enter Volume","Enter Initial Volumetric flow Rate","Enter Rate Constant","Enter upper time limit t"];
        dlg_title = "Input values";
        num_lines = 2;
        def = {'','','',''};
        input = inputdlg(prompt,dlg_title,num_lines,def);
        volume = str2double(input{1});
        Vflow_rate = str2double(input{2});
        k = str2double(input{3});
        time_limit = str2double(input{4}); % upper bond time for cumulative dist.


        space_time = volume/Vflow_rate
        t = linspace(0,60,10000);
        Et =exp(-t./space_time)/space_time;
        plot(t,Et,'r--o') %plot E vs t
        ylabel("E(t) ")
        xlabel("Time")

        E_at_time_limit = exp(-time_limit/space_time)/space_time
        %calculating mean time
        ft = @(t) t.*exp(-t./space_time)/space_time;
        mean_time = integral(ft,0,Inf)
        % calculating variance
        ft = @(t) ((t-mean_time).^2).*exp(-t./space_time)/space_time;
        variance = integral(ft,0,Inf)
        % calculating fraction of molecules residing for less than time t;
        ft = @(t) exp(-t./space_time)/space_time;
        cumulative_dist = integral(ft,0,time_limit)
        % calculating average conversion rate
        X_avg = (space_time*k)/(1+space_time*k)

        %Displaying output
        msgbox(["Mean Time in CSTR is "+num2str(mean_time),"E(t) at given time limit is: "+num2str(E_at_time_limit),"Cumulative distribution is "+ num2str(cumulative_dist),"Variance is "+num2str(variance),"Average Conversion is: "+ X_avg])




        
        
