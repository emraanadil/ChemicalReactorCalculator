choice = menu("Choose how you want to input","In terms of Molar Flow Rate"," In terms of Concentration");
    if choice ==1
       prompt = ["Enter initial Molar Flow Rate of A","Enter initial Molar Flow Rate of B","Enter  conversion of A","Enter rate constant","Enter Initial volumetric flow rate","Enter Initial Mole Fraction of A","Enter change in number of gaseous moles. Enter 0 for liquid phase","Enter Order w.r.t A","Enter Order w.r.t B"];
        dlg_title = "Input values";
        num_lines = 2;
        def = {'','','','','','','','',''};
        input = inputdlg(prompt,dlg_title,num_lines,def);
        fa0 = str2double(input{1});
        fb0 = str2double(input{2});
        X = str2double(input{3});
        k = str2double(input{4});
        v0 = str2double(input{5});
        initial_mole_fraction = str2double(input{6});
        change_in_gaseous_moles = str2double(input{7});
        alpha = str2double(input{8});
        beta = str2double(input{9});
        ca0 = fa0/v0;
        cb0=fb0/v0;
        e = initial_mole_fraction*change_in_gaseous_moles;
        %r = (k * ca0^(alpha+beta)*((1-X)/(1+e*X))^alpha)*((cb0/ca0 -change_in_gaseous_moles*X)/(1+e*X))^beta;
        r = (k*ca0^alpha*cb0^beta*((1-X)^(alpha+beta)))/(1+e*X)^(alpha+beta)
        ca0_range = linspace(0,1000,100)
        reverse_r = 1./((k.*ca0_range.^alpha.*cb0.^beta.*((1-X).^(alpha+beta)))./(1+e.*X).^(alpha+beta))
        plot(ca0_range,reverse_r,'b');
        ylabel("1/-ra")
        xlabel("Ca0")
        volume = X*fa0/r;
    elseif choice ==2
        prompt = ["Enter initial concentration of A","Enter initial concentration of B","Enter  conversion of A","Enter rate constant","Enter Initial volumetric flow rate","Enter Initial Mole Fraction of A","Enter change in number of gaseous moles. Enter 0 for liquid phase","Enter Order w.r.t A","Enter Order w.r.t B"];
        dlg_title = "Input values";
        num_lines = 2;
        def = {'','','','','','','','',''};
        input = inputdlg(prompt,dlg_title,num_lines,def);
        ca0 = str2double(input{1});
        cb0 = str2double(input{2});
        X = str2double(input{3});
        k = str2double(input{4});
        v0 = str2double(input{5});
        initial_mole_fraction = str2double(input{6});
        change_in_gaseous_moles = str2double(input{7});
        alpha = str2double(input{8});
        beta = str2double(input{9});

        e = initial_mole_fraction*change_in_gaseous_moles;

        %r = (k * ca0^alpha+beta)*((1-X)/(1+e*X))^alpha)*((cb0/ca0 +change_in_gaseous_moles*X)/(1+e*X))^beta;
       % r = (k * ca0^alpha * cb0^beta*((1-X)^(alpha+beta)))/(1+e*X)^(alpha+beta)
        r = (k*ca0^alpha*cb0^beta*((1-X)^(alpha+beta)))/(1+e*X)^(alpha+beta);
        
        fa0 = ca0*v0;
        %plotting graph
        ca0_range = linspace(0,1000,100)
        reverse_r = 1./((k.*ca0_range.^alpha.*cb0.^beta.*((1-X).^(alpha+beta)))./(1+e.*X).^(alpha+beta))
        plot(ca0_range,reverse_r,'b');
        ylabel("1/-ra")
        xlabel("Ca0")
        volume = X*fa0/r;
    end

msgbox("Volume of CSTR is "+num2str(volume))

