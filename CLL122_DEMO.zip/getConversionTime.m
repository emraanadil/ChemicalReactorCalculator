prompt = ["Enter initial concentration of A","Enter Final Conversion","Enter  initial conversion of A","Enter rate constant","Enter Order w.r.t A"];
        dlg_title = "Input values";
        num_lines = 2;
        def = {'','','','','','','','',''};
        input = inputdlg(prompt,dlg_title,num_lines,def);
        ca0 = str2double(input{1});
        Xt = str2double(input{2});
        X0 = str2double(input{3});
        k = str2double(input{4});
        alpha = str2double(input{5});
        if alpha == 1
            time_to_convert = (1/k)*log(1/(1-Xt))

        else
            time_to_convert = 1/((alpha-1)*k*ca0^(alpha-1))*((1/(1-Xt)^(alpha-1))-1)
        end
        msgbox(["Time required to convert is " num2str(time_to_convert)]);